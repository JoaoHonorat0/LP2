﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado; 
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtNum3.Text = Resultado.ToString();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtNum3.Text = "";
            Numero1 = 0;
            Numero2 = 0;
            Resultado = 0;
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtNum3.Text = Resultado.ToString();
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtNum3.Text = Resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Número 2 não pode ser 0");
                txtNum2.Focus();

            }
            
            else
            {
                Resultado = Numero1 / Numero2;
                txtNum3.Text = Resultado.ToString();
            }
            
        }

    }

        private void txtNum2_Validated(object sender, EventArgs e)
        { 
            if (!double.TryParse(txtNum2.Text, out Numero2))
            {
                //errorProvider1.setError(txtNum1, "teste");
                MessageBox.Show("número 2 inválido");

            }

        }

      

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out Numero1))
            {
                //errorProvider1.setError(txtNum1, "teste");
                MessageBox.Show("número 1 inválido");
            


            }
        }
    }
}
