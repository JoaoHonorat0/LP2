﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc1
{
    public partial class Form1 : Form
    {
        double Altura, Peso, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Peso inválido");
                txtPeso.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtIMC.Text = "";

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            IMC = Peso / Math.Pow(Altura, 2);

            IMC = Math.Round(IMC, 1);


            if (IMC < 18.5)

                MessageBox.Show("Magreza");
            else if (IMC <= 24.9 && IMC > 18.5)
                MessageBox.Show("Normal");

            else if (IMC <= 29.9 && IMC > 24.9)
                MessageBox.Show("Sobrepeso grau I");

            else if (IMC <= 39.9 && IMC > 29.9)
                MessageBox.Show("Obesidade grau II");
            else 
                    MessageBox.Show("Obesidade Grave");
            txtIMC.Text = IMC.ToString();   



        }
    }
}