﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double SalarioBruto, DescontoINSS, SalarioLiquido, SalarioFamilia, AliquotaINSS, AliquotaIRPF, DescontoIRPF;
        int NumeroFilhos;




        private void btnCalc_Click(object sender, EventArgs e)
        {

            if (SalarioBruto <= 800.47)
            {
                txtAlqINSS.Text = "7,65%";
                DescontoINSS = (7.65 / 100) * SalarioBruto;
            }

            else if (SalarioBruto <= 1050)
            {
                txtAlqIRPF.Text = "8.65%";
                DescontoINSS = (8.65 / 100) * SalarioBruto;
            }

            else if (SalarioBruto <= 1400.77)

            {
                txtAlqINSS.Text = "9%";
                DescontoINSS = (9 / 100) * SalarioBruto;
            }
            else if (SalarioBruto <= 2801) {
                txtAlqINSS.Text = "11%";
                DescontoINSS = (11 / 100) * SalarioBruto;
            }
            else 
            {
                txtAlqINSS.Text = "Teto";
                DescontoINSS = SalarioBruto - 308.17;
            }

            if (SalarioBruto <= 1257.12) {
                txtAlqIRPF.Text = "Isento";
            }

            else if (SalarioBruto >= 1257.13 && SalarioBruto <= 2512.08)
            {


                txtAlqIRPF.Text = "15%";
                DescontoIRPF = (15 / 100) * SalarioBruto
                    }




            else
            {
                txtAlqINSS.Text = "27.5%";


                DescontoIRPF = (27.5 / 100) * SalarioBruto
                    }


            if (SalarioBruto <= 453.52) 
            {
                SalarioFamilia = SalarioBruto + (22.3 + NumeroFilhos);
                    
            else if (SalarioBruto >= 453.53 && SalarioBruto <= 654.61) {
                SalarioFamilia = SalarioBruto + (15.74 * NumeroFilhos);
                    }

            else 
            {
                SalarioFamilia = 0;
            }

            SalarioLiquido = SalarioBruto - DescontoINSS - DescontoIRPF + SalarioFamilia;
        }

        private void txtSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalBruto.Text, out SalarioBruto))

            {
                MessageBox.Show("Salário inválido");
                txtSalBruto.Focus();    
            }
         
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
                char.IsPunctuation(e.KeyChar);
            {
                MessageBox.Show("Caracter inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }
    }
}
