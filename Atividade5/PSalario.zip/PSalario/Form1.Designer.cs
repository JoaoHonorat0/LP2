﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblDesIRPF = new System.Windows.Forms.Label();
            this.lblSalFml = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblSalLqd = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblAlqINSS = new System.Windows.Forms.Label();
            this.lblAlqIRPF = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalBruto = new System.Windows.Forms.TextBox();
            this.txtAlqINSS = new System.Windows.Forms.TextBox();
            this.txtSalFml = new System.Windows.Forms.TextBox();
            this.txtSalLqd = new System.Windows.Forms.TextBox();
            this.txtAlqIRPF = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.NupFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnCalc = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(30, 63);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(90, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(30, 108);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(66, 13);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salário bruto";
            // 
            // lblDesIRPF
            // 
            this.lblDesIRPF.AutoSize = true;
            this.lblDesIRPF.Location = new System.Drawing.Point(384, 385);
            this.lblDesIRPF.Name = "lblDesIRPF";
            this.lblDesIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDesIRPF.TabIndex = 2;
            this.lblDesIRPF.Text = "Desconto IRPF";
            // 
            // lblSalFml
            // 
            this.lblSalFml.AutoSize = true;
            this.lblSalFml.Location = new System.Drawing.Point(30, 385);
            this.lblSalFml.Name = "lblSalFml";
            this.lblSalFml.Size = new System.Drawing.Size(76, 13);
            this.lblSalFml.TabIndex = 3;
            this.lblSalFml.Text = "Salário Família";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(30, 174);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblNumFilhos.TabIndex = 4;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // lblSalLqd
            // 
            this.lblSalLqd.AutoSize = true;
            this.lblSalLqd.Location = new System.Drawing.Point(384, 263);
            this.lblSalLqd.Name = "lblSalLqd";
            this.lblSalLqd.Size = new System.Drawing.Size(74, 13);
            this.lblSalLqd.TabIndex = 5;
            this.lblSalLqd.Text = "Salário líquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(384, 317);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 6;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblAlqINSS
            // 
            this.lblAlqINSS.AutoSize = true;
            this.lblAlqINSS.Location = new System.Drawing.Point(30, 256);
            this.lblAlqINSS.Name = "lblAlqINSS";
            this.lblAlqINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAlqINSS.TabIndex = 7;
            this.lblAlqINSS.Text = "Aliquota INSS";
            // 
            // lblAlqIRPF
            // 
            this.lblAlqIRPF.AutoSize = true;
            this.lblAlqIRPF.Location = new System.Drawing.Point(30, 321);
            this.lblAlqIRPF.Name = "lblAlqIRPF";
            this.lblAlqIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAlqIRPF.TabIndex = 8;
            this.lblAlqIRPF.Text = "Aliquota IRPF";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(143, 56);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(381, 20);
            this.txtNome.TabIndex = 9;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(143, 101);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalBruto.TabIndex = 10;
            this.txtSalBruto.Validated += new System.EventHandler(this.txtSalBruto_Validated);
            // 
            // txtAlqINSS
            // 
            this.txtAlqINSS.Enabled = false;
            this.txtAlqINSS.Location = new System.Drawing.Point(143, 256);
            this.txtAlqINSS.Name = "txtAlqINSS";
            this.txtAlqINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAlqINSS.TabIndex = 11;
            // 
            // txtSalFml
            // 
            this.txtSalFml.Enabled = false;
            this.txtSalFml.Location = new System.Drawing.Point(143, 378);
            this.txtSalFml.Name = "txtSalFml";
            this.txtSalFml.Size = new System.Drawing.Size(100, 20);
            this.txtSalFml.TabIndex = 12;
            // 
            // txtSalLqd
            // 
            this.txtSalLqd.Enabled = false;
            this.txtSalLqd.Location = new System.Drawing.Point(477, 252);
            this.txtSalLqd.Name = "txtSalLqd";
            this.txtSalLqd.Size = new System.Drawing.Size(100, 20);
            this.txtSalLqd.TabIndex = 13;
            // 
            // txtAlqIRPF
            // 
            this.txtAlqIRPF.Enabled = false;
            this.txtAlqIRPF.Location = new System.Drawing.Point(143, 314);
            this.txtAlqIRPF.Name = "txtAlqIRPF";
            this.txtAlqIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAlqIRPF.TabIndex = 14;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(477, 378);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRPF.TabIndex = 16;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(477, 310);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 17;
            // 
            // NupFilhos
            // 
            this.NupFilhos.Location = new System.Drawing.Point(143, 167);
            this.NupFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NupFilhos.Name = "NupFilhos";
            this.NupFilhos.Size = new System.Drawing.Size(120, 20);
            this.NupFilhos.TabIndex = 18;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(477, 174);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 19;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.NupFilhos);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtAlqIRPF);
            this.Controls.Add(this.txtSalLqd);
            this.Controls.Add(this.txtSalFml);
            this.Controls.Add(this.txtAlqINSS);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblAlqIRPF);
            this.Controls.Add(this.lblAlqINSS);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLqd);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalFml);
            this.Controls.Add(this.lblDesIRPF);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblDesIRPF;
        private System.Windows.Forms.Label lblSalFml;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblSalLqd;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblAlqINSS;
        private System.Windows.Forms.Label lblAlqIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalBruto;
        private System.Windows.Forms.TextBox txtAlqINSS;
        private System.Windows.Forms.TextBox txtSalFml;
        private System.Windows.Forms.TextBox txtSalLqd;
        private System.Windows.Forms.TextBox txtAlqIRPF;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.NumericUpDown NupFilhos;
        private System.Windows.Forms.Button btnCalc;
    }
}

